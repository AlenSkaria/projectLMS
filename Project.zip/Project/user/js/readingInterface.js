// const booksData = {
//   bookId: 1,
//   title: "The Great Gatsby",
//   author: "F. Scott Fitzgerald",
//   category: "Fiction",
//   availableFor: ["buy", "rent"],
//   price: 15.0,
//   rentPrice: 5.0,
//   coverImage: "../../assets/book/1.jpg",
//   description:
//     "A portrait of the Jazz Age in all of its decadence and excess, The Great Gatsby is one of the great American novels.",
//   pages: [
//     "Attending Denison was one of the best decisions of my life. I earned a spot on the baseball team and, although I was at the bottom of the roster as a freshman, I was thrilled. Despite the chaos of my high school years, I had managed to become a college athlete.I wasn’t going to be starting on the baseball team anytime soon, so I focused on getting my life in order. While my peers stayed up late and played video games, I built good sleep habits and went to bed early each night. In the messy world of a college dorm, I made a point to keep my room neat and tidy. These improvements were minor, but they gave me a sense of control over my life. I started to feel confident again. And this growing belief in myself rippled into the classroom as I improved my study habits and managed to earn straight A’s during my first year.A habit is a routine or behavior that is performed regularly—and, in many cases, automatically. As each semester passed, I accumulated small but consistent habits that ultimately led to results that were unimaginable to me when I started. For example, for the first time in my life, I made it a habit to lift weights multiple times per week, and in the years that followed, my six-footfour-inch frame bulked up from a featherweight 170 to a lean 200 pounds.When my sophomore season arrived, I earned a starting role on the pitching staff. By my junior year, I was voted team captain and at the end of the season, I was selected for the all-conference team. But it was not until my senior season that my sleep habits, study habits, and strength-training habits really began to pay off.Six years after I had been hit in the face with a baseball bat, flown to the hospital, and placed into a coma, I was selected as the top male athlete at Denison University and named to the ESPN Academic All-America Team—an honor given to just thirty-three players across the country. By the time I graduated, I was listed in the school record books in eight different categories. That same year, I was awarded the university’s highest academic honor, the President’s Medal.",
//     "The following months were hard. It felt like everything in my life was on pause. I earned a spot on the baseball team and, although I was at the bottom of the roster as a freshman, I was thrilled. Despite the chaos of my high school years, I had managed to become a college athlete.I wasn’t going to be starting on the baseball team anytime soon, so I focused on getting my life in order. While my peers stayed up late and played video games, I built good sleep habits and went to bed early each night. In the messy world of a college dorm, I made a point to keep my room neat and tidy. These improvements were minor, but they gave me a sense of control over my life. I started to feel confident again. And this growing belief in myself rippled into the classroom as I improved my study habits and managed to earn straight A’s during my first year.A habit is a routine or behavior that is performed regularly—and, in many cases, automatically. As each semester passed, I accumulated small but consistent habits that ultimately led to results that were unimaginable to me when I started. For example, for the first time in my life, I made it a habit to lift weights multiple times per week, and in the years that followed, my six-footfour-inch frame bulked up from a featherweight 170 to a lean 200 pounds.When my sophomore season arrived, I earned a starting role on the pitching staff. By my junior year, I was voted team captain and at the end of the season, I was selected for the all-conference team. But it was not until my senior season that my sleep habits, study habits, and strength-training habits really began to pay off.Six years after I had been hit in the face with a baseball bat, flown to the hospital, and placed into a coma, I was selected as the top male athlete at Denison University and named to the ESPN Academic All-America Team—an honor given to just thirty-three players across the country. By the time I graduated, I was listed in the school record books in eight different categories. That same year, I was awarded the university’s highest academic honor, the President’s Medal.",
//     "I became painfully aware of how far I had to go when I returned to the baseball field one year later. I earned a spot on the baseball team and, although I was at the bottom of the roster as a freshman, I was thrilled. Despite the chaos of my high school years, I had managed to become a college athlete.I wasn’t going to be starting on the baseball team anytime soon, so I focused on getting my life in order. While my peers stayed up late and played video games, I built good sleep habits and went to bed early each night. In the messy world of a college dorm, I made a point to keep my room neat and tidy. These improvements were minor, but they gave me a sense of control over my life. I started to feel confident again. And this growing belief in myself rippled into the classroom as I improved my study habits and managed to earn straight A’s during my first year.A habit is a routine or behavior that is performed regularly—and, in many cases, automatically. As each semester passed, I accumulated small but consistent habits that ultimately led to results that were unimaginable to me when I started. For example, for the first time in my life, I made it a habit to lift weights multiple times per week, and in the years that followed, my six-footfour-inch frame bulked up from a featherweight 170 to a lean 200 pounds.When my sophomore season arrived, I earned a starting role on the pitching staff. By my junior year, I was voted team captain and at the end of the season, I was selected for the all-conference team. But it was not until my senior season that my sleep habits, study habits, and strength-training habits really began to pay off.Six years after I had been hit in the face with a baseball bat, flown to the hospital, and placed into a coma, I was selected as the top male athlete at Denison University and named to the ESPN Academic All-America Team—an honor given to just thirty-three players across the country. By the time I graduated, I was listed in the school record books in eight different categories. That same year, I was awarded the university’s highest academic honor, the President’s Medal.",
//     "But my return to baseball was not smooth. When the season rolled around, I was the only junior to be cut from the varsity baseball team. I earned a spot on the baseball team and, although I was at the bottom of the roster as a freshman, I was thrilled. Despite the chaos of my high school years, I had managed to become a college athlete.I wasn’t going to be starting on the baseball team anytime soon, so I focused on getting my life in order. While my peers stayed up late and played video games, I built good sleep habits and went to bed early each night. In the messy world of a college dorm, I made a point to keep my room neat and tidy. These improvements were minor, but they gave me a sense of control over my life. I started to feel confident again. And this growing belief in myself rippled into the classroom as I improved my study habits and managed to earn straight A’s during my first year.A habit is a routine or behavior that is performed regularly—and, in many cases, automatically. As each semester passed, I accumulated small but consistent habits that ultimately led to results that were unimaginable to me when I started. For example, for the first time in my life, I made it a habit to lift weights multiple times per week, and in the years that followed, my six-footfour-inch frame bulked up from a featherweight 170 to a lean 200 pounds.When my sophomore season arrived, I earned a starting role on the pitching staff. By my junior year, I was voted team captain and at the end of the season, I was selected for the all-conference team. But it was not until my senior season that my sleep habits, study habits, and strength-training habits really began to pay off.Six years after I had been hit in the face with a baseball bat, flown to the hospital, and placed into a coma, I was selected as the top male athlete at Denison University and named to the ESPN Academic All-America Team—an honor given to just thirty-three players across the country. By the time I graduated, I was listed in the school record books in eight different categories. That same year, I was awarded the university’s highest academic honor, the President’s Medal.",
//     "Despite my lackluster high school career, I still believed I could become a great player.. I earned a spot on the baseball team and, although I was at the bottom of the roster as a freshman, I was thrilled. Despite the chaos of my high school years, I had managed to become a college athlete.I wasn’t going to be starting on the baseball team anytime soon, so I focused on getting my life in order. While my peers stayed up late and played video games, I built good sleep habits and went to bed early each night. In the messy world of a college dorm, I made a point to keep my room neat and tidy. These improvements were minor, but they gave me a sense of control over my life. I started to feel confident again. And this growing belief in myself rippled into the classroom as I improved my study habits and managed to earn straight A’s during my first year.A habit is a routine or behavior that is performed regularly—and, in many cases, automatically. As each semester passed, I accumulated small but consistent habits that ultimately led to results that were unimaginable to me when I started. For example, for the first time in my life, I made it a habit to lift weights multiple times per week, and in the years that followed, my six-footfour-inch frame bulked up from a featherweight 170 to a lean 200 pounds.When my sophomore season arrived, I earned a starting role on the pitching staff. By my junior year, I was voted team captain and at the end of the season, I was selected for the all-conference team. But it was not until my senior season that my sleep habits, study habits, and strength-training habits really began to pay off.Six years after I had been hit in the face with a baseball bat, flown to the hospital, and placed into a coma, I was selected as the top male athlete at Denison University and named to the ESPN Academic All-America Team—an honor given to just thirty-three players across the country. By the time I graduated, I was listed in the school record books in eight different categories. That same year, I was awarded the university’s highest academic honor, the President’s Medal.",
//   ],
// };

let booksData = null;
booksData = localStorage.getItem("selectedBook");
booksData = JSON.parse(booksData);
console.log(booksData);
function changeImage() {
  const img = document.getElementById("myImage");
  img.src = booksData.coverImage;
}
function addDescription() {
  const name = document.getElementById("name");
  const author = document.getElementById("author");
  name.innerHTML = booksData.title;
  author.innerHTML = booksData.author;
}

// test

const PAGE_SIZE = 1; // Number of pages to display per page
let currentPage = 0; // Current page index

// test
function renderPages() {
  const startPageIndex = currentPage * PAGE_SIZE;
  const endPageIndex = startPageIndex + PAGE_SIZE;
  const pagesContainer = document.getElementById("pages-container");

  pagesContainer.innerHTML = ""; // Clear previous content

  // Display the current page content
  const currentPages = booksData.pages.slice(startPageIndex, endPageIndex);
  currentPages.forEach((pageContent, index) => {
    const pageDiv = document.createElement("div");
    pageDiv.innerText = pageContent;
    pagesContainer.appendChild(pageDiv);
  });

  // Update pagination info
  document.getElementById("page-info").innerText = `Page ${
    currentPage + 1
  } of ${Math.ceil(booksData.pages.length / PAGE_SIZE)}`;

  // Enable/disable buttons based on current page
  document.getElementById("prev-button").disabled = currentPage === 0;
  document.getElementById("next-button").disabled =
    currentPage === Math.ceil(booksData.pages.length / PAGE_SIZE) - 1;
}

// Event listeners for pagination buttons
document.getElementById("prev-button").addEventListener("click", () => {
  if (currentPage > 0) {
    currentPage--;
    renderPages();
  }
});

document.getElementById("next-button").addEventListener("click", () => {
  if (currentPage < Math.ceil(booksData.pages.length / PAGE_SIZE) - 1) {
    currentPage++;
    renderPages();
  }
});

// test
function closePage() {
  history.back();
}

document.addEventListener("DOMContentLoaded", () => {
  //   changeImage();
  //   addDescription();
  renderPages();
});
